package test;
import test.Foundation;

public class MainClass extends Foundation{

	public static void main(String[] args) {
		MainClass mc=new MainClass();
		System.out.println(mc.Var1);			//In-Accessible
		System.out.println(mc.Var2);			//Accessible
		System.out.println(mc.Var3);			//Accessible
		System.out.println(mc.Var4);			//Accessible
	}

}
