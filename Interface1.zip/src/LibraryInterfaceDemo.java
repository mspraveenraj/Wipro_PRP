
public class LibraryInterfaceDemo {

	public static void main(String[] args) {
		KidUser ku=new KidUser();
		ku.age=10;
		ku.registerAccount();
		ku.age=18;
		ku.registerAccount();
		
		ku.bookType="Kids";
		ku.requestBook();
		ku.bookType="Friction";
		ku.requestBook();
		
		AdultUser au=new AdultUser();
		au.age=5;
		au.registerAccount();
		au.age=23;
		au.registerAccount();
		
		au.bookType="Kids";
		au.requestBook();
		au.bookType="Friction";
		au.requestBook();
	}

}
