class Sum
{
	int sum = 0;
	void disp(String[] args) throws Exception
	{
	for (int i = 0; i < args.length; i++) 
	{
    sum = sum + Integer.parseInt(args[i]);
	}
	float avg=sum/args.length;
	System.out.println("Sum : " + sum);
	System.out.println("Average : "+avg);
	}
}

public class Exception4 {

    public static void main (String[] args) throws Exception 
    {
    	
    Sum s=new Sum();
    try
    {
    s.disp(args);
    }
    catch(NumberFormatException e)
    {
    	System.out.println("Number Format Exception "+e.getMessage());
    }
    catch(ArithmeticException e)
    {
    	System.out.println(e.getMessage());
    }
    }
}