import java.util.*;
class NegativeValueException extends Exception
{
	NegativeValueException()
	{
		System.out.print("Negative Marks Entered ");
	}
}

public class Exception6 {

	public static void main(String[] args) throws Exception {
		Scanner in=new Scanner(System.in);
		String marks[][]=new String[2][3];
		int d[]=new int[3];
		try
		{
			String name[]=new String[2];
			for(int i=0;i<2;i++)
			{
				name[i]=in.next();
				for(int j=0;j<3;j++)
				{
					marks[i][j]=in.next();
					d[j]=Integer.parseInt(marks[i][j]);
					if(d[j]<0||d[j]>100)
						throw new NegativeValueException();
				}
			}
		
			for(int i=0;i<2;i++)
			{
				System.out.println("    Student "+(i+1));
				System.out.println("Name : "+name[i]);
		
				for(int j=0;j<3;j++)
				{
					System.out.println("Marks "+ (j+1) + ": " +marks[i][j]);
				}  
			}
		}
		catch(NegativeValueException e)
		{
			System.out.println(e.getMessage());
		}
		catch(NumberFormatException e)
		{
			System.out.println("Error" + e.getMessage());
		}
		catch(Exception e)
		{
			System.out.println("Invalid");
		}
		in.close();
	}
}
