import java.util.*;
public class Exception1 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		String str=in.next();
		try
		{
		int num=Integer.parseInt(str);
		System.out.println("The work has been done successfully");
		System.out.println("Square is : "+num*num);
		}
		catch(NumberFormatException e)
		{
			System.out.println("Entered input is not a valid format for an integer.");
		}
		in.close();
	}

}
