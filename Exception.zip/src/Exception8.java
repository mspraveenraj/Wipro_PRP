class AgeException extends Exception
{
	AgeException()
	{
		System.out.println("User Defined Exception : ");
	}
}
public class Exception8 {

	public static void main(String[] args) throws AgeException {
		try
		{
		String name=args[0];
		int age=Integer.parseInt(args[1]);
		if(age>=18 && age<60)
			System.out.println("Nmae : "+name+"\nYou are Eligeable");
		else
			throw new AgeException();
	}
		catch(AgeException e)
		{
			System.out.println("Age is Invalid");
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Invalid Input");
		}
	}
}
