import java.util.*;

class DivideByZeroException extends Exception
{
	int c;
	DivideByZeroException() 
	{
		System.out.println("User Defined Exception : ");
	}
}
public class Exception9 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int a=in.nextInt();
		int b=in.nextInt();
		try
		{
		if(b==0)
			throw new DivideByZeroException();
		System.out.println("The quotient of "+a+" / "+b+" = "+a/b);
		}
		catch(DivideByZeroException e)
		{
			System.out.println("DivideByZeroException caught");
		}
		finally
		{
			System.out.println("Inside finally block");
			in.close();
		}
	}

}
