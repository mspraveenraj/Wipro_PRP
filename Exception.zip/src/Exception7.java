
class InvalidCountryException extends Exception
{
	InvalidCountryException(String str)
	{
		System.out.println(str);
	}
}
public class Exception7 {
	void registerUser(String username,String userCountry) throws InvalidCountryException
	{
		if(!userCountry.equals("India"))
			throw new InvalidCountryException("User Outside India  cannot be registered");
		else
			System.out.println("User registration done successfully");
	}
	public static void main(String[] args)
	{
		Exception7 exp=new Exception7();
		try
		{
		exp.registerUser("Raj", "India");
		exp.registerUser("Praveen", "US");
		}
		catch(InvalidCountryException e)
		{
			System.out.println(e);
		}
	}
}
