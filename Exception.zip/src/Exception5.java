import java.util.*;

class Arithmetic
{
	int disp(int a,int b) throws ArithmeticException
	{
		return a/b;
	}
}
public class Exception5 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		Arithmetic ar=new Arithmetic();
		System.out.println("Enter two integers to Divide");
		int a=in.nextInt();
		int b=in.nextInt();
		in.close();
		try
		{
			System.out.println("Division Value : "+ar.disp(a,b));
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
	}
}
