import java.io.*;

public class Io4_Obj_Serialize1 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		FileInputStream fin=new FileInputStream("Fout.txt");
		ObjectInputStream objIn=new ObjectInputStream(fin);
		Io4_Obj_Serialize i=(Io4_Obj_Serialize)objIn.readObject();
		System.out.println("Name : "+i.name+"\nDate of Birth : "+i.dateOfBirth+"\nDepartment : "+i.department+"\nDesignation : "+i.designation+"\nSalary : "+i.salary);
		fin.close();
	}

}
