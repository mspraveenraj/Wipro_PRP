import java.io.*;
import java.util.*;

public class Io1 {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the file name");
		File f=new File(br.readLine());
		System.out.println("Enter the character to be counted");
		char c=(char) br.read();
		int count=0;
		FileReader fr=new FileReader(f);
		int a;
		while((a=fr.read())!=-1){
			if(fr.read()==c)
				count++;
		}
		System.out.println("File "+f.getName()+" has "+count+" instance of letter '"+c+"'");
		fr.close();

	}

}
