import java.io.*;

@SuppressWarnings("serial")
public class Io4_Obj_Serialize implements Serializable {

	String name;
	transient String dateOfBirth;
	String department;
	String designation;
	double salary;
	
	public void setName(String name) {
		this.name = name;
	}


	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public static void main(String[] args) throws IOException {
		Io4_Obj_Serialize i=new Io4_Obj_Serialize();
		
		i.setName("Raj");
		i.setDateOfBirth("28/04/1997");
		i.setDepartment("CSE");
		i.setDesignation("Student");
		i.setSalary(20000);
		FileOutputStream fout=new FileOutputStream("Fout.txt");
		ObjectOutputStream objOut=new ObjectOutputStream(fout);
		objOut.writeObject(i);
		objOut.close();
		
	}

}
