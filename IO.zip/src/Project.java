import java.io.*;

public class Project {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		int id;
		String name;
		int age;
		double salary;
		
		BufferedReader br =new BufferedReader(new InputStreamReader(System.in));
		int n;
		
		File fout=new File("Fout1.txt");
		
		FileWriter fin=new FileWriter(fout);
		
		do
		{
			System.out.println("Main Menu\n1. Add an Employee\n2. Display All\n3.Exit");
			n=Integer.parseInt(br.readLine());
			System.out.println(n);
			switch(n)
			{
			case 1: System.out.println("Enter Employee ID :");
					id=Integer.parseInt(br.readLine());
					System.out.println("Enter Employee Name");
					name=br.readLine();
					System.out.println("Enter Employee Age");
					age=Integer.parseInt(br.readLine());
					System.out.println("Enter Employee Salary");
					salary=Double.parseDouble(br.readLine());
				
					fin.write(id+" "+name+" "+age+" "+salary+"\n");
				
					fin.flush();
			
					break;
				
			case 2: System.out.println("-----Report-----");
					FileReader fr = new FileReader(fout); 
					char [] a = new char[50];
					fr.read(a);   
	      
					for(char c : a)
						System.out.print(c);
					fr.close();
	      
					System.out.println("\n-----End of Report-----");
					break;
				
			case 3: System.out.println("Exiting System");
					System.exit(0);
			}
		}while(n>=1 && n<=3);
		fin.close();
	}
}
