import java.io.*;

public class Io2 {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter the input file name");
		File f=new File(br.readLine());
		FileReader fr=new FileReader(f);
		FileWriter fw=new FileWriter("Output.txt");
		int i;
		while((i=fr.read())!=-1)
		{
			fw.write(i);
		}
		fr.close();
		fw.close();
	}
}
