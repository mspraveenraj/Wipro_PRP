import java.util.*;
import java.io.*;

public class Io3 {

	public static void main(String[] args) throws IOException {
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the file name");
		File f=new File(br.readLine());
		//FileReader fr=new FileReader(f);
		FileWriter fw=new FileWriter("Output.txt");
		
		HashMap<String,Integer> map=new HashMap<String, Integer>();
		
		String str;
		BufferedReader br1=new BufferedReader(new FileReader(f));
		
		while((str=br1.readLine())!=null)
		{
			//str.replaceAll("\\n", "\\s");
			String[] words=str.split("\\s");
		
			
			int j=0;
			while(j<words.length)
			{
				int c=1;
				int i=0;
			while(i<words.length)
			{
				if(words[j].equalsIgnoreCase(words[i]) && i!=j)
				{
					c++;System.out.println(c);
				}
				i++;
			}
			map.put(words[j],c);
			j++;
			}
		}
		
		Set set=map.entrySet();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry mt=(Map.Entry)it.next();
			String str1=mt.getKey()+" "+mt.getValue()+" ";
			//System.out.println(str1);
			fw.write(str1);
		}
		fw.close();
	}

}
