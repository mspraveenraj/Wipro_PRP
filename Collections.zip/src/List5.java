import java.util.*;

public class List5 {
	int id;
	String name;
	String address;
	double sal;
	
	List5(int id, String name, String address,double sal)
	{
		this.id=id;
		this.name=name;
		this.address=address;
		this.sal=sal;
	}
	
	public String toString()
	{
		return id+" "+name+" "+address+" "+sal;
	}
	
	public static void main(String[] args) {
		ArrayList<List5> list=new ArrayList<List5>();
		
		List5 l1=new List5(111,"Raj","Chennai",50000);
		List5 l2=new List5(222,"Praveen","Kovai",60000);
		List5 l3=new List5(333,"Kumar","Salem",70000);
		
		list.add(l1);
		list.add(l2);
		list.add(l3);
		
		Iterator<List5> it=list.iterator();
	
		System.out.println("Enter the id to Search an Employee");
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		
		while(it.hasNext())
		{
			List5 lt=(List5)it.next();
			if(lt.id==n)
			{
				System.out.println(lt);
				break;
			}
		}
		in.close();
	}
}
