import java.util.*;

public class Map4 {

	public static void main(String[] args) {
		Map mp=new  HashMap();
		mp.put("Raj",1234567890);
		mp.put("Praveen", 235647534);
		mp.put("Kumar",343245350);
		
		String name="Praveen";
		Set set=mp.entrySet();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry st=(Map.Entry)it.next();
			if(st.getKey().equals(name))
				System.out.println(st.getKey() +" : " +st.getValue());
		}
	}
}
