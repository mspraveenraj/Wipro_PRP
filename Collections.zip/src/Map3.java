import java.util.*;

public class Map3 {

	public static void main(String[] args) {
		Properties p=new Properties();
		p.setProperty("TamilNadu","Chennai");
		p.setProperty("Kerala","Trivandrum");
		p.setProperty("Andhra Pradesh","Amaravathy");
		p.setProperty("Karnataka", "Bengaluru");
		
		Set set=p.entrySet();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}

}
