import java.util.*;

public class List6 {
	LinkedList<Integer> A1=new LinkedList<Integer>();
	LinkedList<Integer> A2=new LinkedList<Integer>();
	
	LinkedList<Integer> saveEvenNumbers(int N)
	{
		for(int i=2;i<=N;i+=2)
		{
			A1.add(i);
		}
		return A1;
	}
	
	LinkedList<Integer> printEvenNumbers()
	{
		ListIterator<Integer> it=A1.listIterator();
		while(it.hasNext())
		{	A2.add(2*it.next());
			it.previous();
			System.out.print(2*it.next()+" ");
		}
		return A2;
	}
	
	int printEvenNumber(int N)
	{
		if(A1.contains(N))
			return N;
		return 0;
	}
	
	public static void main(String[] args) {
		System.out.println("Enter the Number : ");
		Scanner in=new Scanner(System.in);
		int N=in.nextInt();
		
		List6 l=new List6();
		
		l.saveEvenNumbers(N);
		l.printEvenNumbers();
		
		System.out.println("\nEnter the number to Search :");
		
		int m=in.nextInt();
		
		System.out.println(l.printEvenNumber(m));
		
		in.close();
	}

}
