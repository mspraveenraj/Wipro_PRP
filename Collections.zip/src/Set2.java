import java.util.*;

public class Set2 {
	
	public static void main(String[] args) {
		String[] a={"Raj","Praveen","Kumar","ABC","Raj"};
		
		HashSet<String> emp=new HashSet<String>(Arrays.asList(a));
				
		Iterator<String> it=emp.iterator();
		
		while(it.hasNext())
		{
			String st=(String) it.next();
			System.out.println(st);
		}
	}

}
