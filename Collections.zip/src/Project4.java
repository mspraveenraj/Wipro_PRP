import java.util.*;
public class Project4 {
	String symbol;
	int number;
	LinkedHashMap map=new LinkedHashMap();
	

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		
		Project4 p=new Project4();
		System.out.println("Enter Number of cards");
		int n=in.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter card "+(i+1)+":");
			p.symbol=in.next();
			p.number=in.nextInt();
			p.map.put(p.symbol, p.number);
		}
		
		TreeSet ts=new TreeSet();
		Set s1=p.map.entrySet();
		Iterator it=s1.iterator();
		while(it.hasNext())
		{
			Map.Entry st=(Map.Entry)it.next();
			 ts.add(st.getKey());
		}
		
		System.out.println("Distinct Symbols are :");
		Iterator it1=ts.iterator();
		while(it1.hasNext())
		{
			System.out.println(it1.next());
		}
	
		Iterator it2=s1.iterator();
		Iterator it3=ts.iterator();
		
		while(it3.hasNext())
		{
			int i=1;
			Map.Entry st=(Map.Entry)it2.next();
			while(i<n){
			if(it.next().equals(st.getKey()))
			{	
				System.out.println(st.getKey()+" "+st.getValue());
			}i++;
			
			}System.out.println("Number of cards :"+i);
		
		}

	}

}
