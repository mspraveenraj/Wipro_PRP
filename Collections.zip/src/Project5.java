import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;


public class Project5 {

	double length;
	double width;
	double height;
	Double volume;
	public String toString()
	{
	return length+" "+ width+ " "+height +" "+length*width*height;
	}
	public static void main(String[] args) throws IOException {
		//Scanner in=new Scanner(System.in);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		Set ts=new LinkedHashSet();
		
		System.out.println("Enter the number of Box");
		int n=Integer.parseInt(br.readLine());
		System.out.println(n);
		for(int i=0;i<n;i++)
		{
			Project5 p=new Project5();
			System.out.println("Enter length");
			p.length=Double.parseDouble(br.readLine());
			System.out.println("Enter width");
			p.width=Double.parseDouble(br.readLine());
			System.out.println("Enter heigth");
			p.height=Double.parseDouble(br.readLine());
			p.volume=p.length*p.width*p.height;
			ts.add(p);
		}
		Project5 p1=new Project5();
		Iterator it=ts.iterator();
		int i=0;
		while(it.hasNext())
		{
			Project5 p5=(Project5)it.next();
			//System.out.println(it.next());
			//if(p5.equals(p1))
				System.out.println(p5.volume);
		}

	}
	public boolean equals(Project5 obj) {
		
		if(obj==this)
			return false;
		
            return true;
        //}
			//return (Double.compare(volume, obj.volume)== 0);
	}
	 
}
