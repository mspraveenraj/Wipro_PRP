import java.util.*;

public class Map1 {

	String CountryName;
	String capital;
	
	HashMap<String, String> CountryMap=new HashMap<String, String>();
	Set set=CountryMap.entrySet();
	
	Map1()
	{
		
	}
	
	Map1(String CountryName,String capital)
	{
		this.CountryName=CountryName;
		this.capital=capital;
	}
	
	Map<String, String> saveCountryCapital(String CountryName, String capital)
	{
		CountryMap.put(CountryName,capital);
		return CountryMap;
	}
	
	String getCapital(String CountryName)
	{
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry st=(Map.Entry)it.next();
			if(st.getKey().equals(CountryName))
			{
				return (String) st.getValue();
			}
		}
		return null;
	}
	
	String getCountry(String capitalName)
	{
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry st=(Map.Entry)it.next();
			if(st.getValue().equals(capitalName))
			{
				return (String)st.getKey();
			}
		}
		return null;
	}
	
	Map interchange()
	{
		Map M2=new HashMap();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry st1=(Map.Entry)it.next();
			M2.put(st1.getValue(),st1.getKey());
		}
		return M2;
	}
	
	ArrayList arrayList()
	{
		ArrayList arr=new ArrayList();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			Map.Entry st2=(Map.Entry)it.next();
			arr.add(st2.getKey());
		}
		return arr;
	}
	
	public static void main(String[] args) {
		Map1 mp=new Map1();
		
		System.out.println(mp.saveCountryCapital("India", "New Delhi"));
		System.out.println(mp.saveCountryCapital("China","Beijing"));
		System.out.println(mp.saveCountryCapital("Japan","Tokyo"));
		System.out.println(mp.getCapital("India"));
		System.out.println(mp.getCountry("Tokyo"));
		System.out.println(mp.interchange());
		System.out.println(mp.arrayList());
	}

}
