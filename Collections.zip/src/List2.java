import java.util.*;

class EmployeeDB
{
	ArrayList<List2> emp=new ArrayList<List2>();
	
	boolean addEmployee(List2 e)
	{
		 emp.add(e);
		 //System.out.println(emp.get(0));
		 return true;
	}
	
	boolean deleteEmployee(int eCode) 
	{
		ListIterator<List2> it=emp.listIterator();
		int i=0;
		while(it.hasNext())
		{
			List2 lt=(List2)it.next();
			if(lt.eCode==eCode)
			{
				 emp.remove(i);
				return true;
			}
			i++;
		}
			return false;
	}
	
	String showPaySlip(int eCode)
	{
		ListIterator<List2> it=emp.listIterator();
		while(it.hasNext())
		{
			List2 lt=(List2)it.next();
			if(lt.eCode==eCode)
			{
				return lt.toString();
			}
		}
		return "Invaid";
	}
	
	List2[] listAll()
	{
		List2[] arr= emp.toArray(new List2[emp.size()]);
		return arr;
	}
	
	public String toString()
	{
		return emp.toString();
	}
}

public class List2 {

	int eCode;
	String name;
	String paySlip;
	
	List2(int eCode,String name,String paySlip)
	{
		this.eCode=eCode;
		this.name=name;
		this.paySlip=paySlip;
	}
	
	public String toString()
	{
		return eCode+name+paySlip;
	}

	public static void main(String[] args) {
		EmployeeDB edb=new EmployeeDB();
		List2 l=new List2(123,"Raj","10000");
		List2 li=new List2(121,"Praveen","20000");
		List2 l1=new List2(125,"Pr","50000");
		
		System.out.println(edb.addEmployee(l1));
		System.out.println(edb.addEmployee(l));
		System.out.println(edb.addEmployee(li));
		System.out.println(edb.deleteEmployee(123));
		System.out.println(edb.showPaySlip(121));
		
		List2[] arr=edb.listAll();
		System.out.println("Emp Id\t\tEmp Name\tpaySlip");
		for(int i=0;i<arr.length;i++)
			System.out.println(arr[i].toString());
	}

}
