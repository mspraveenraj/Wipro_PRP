import java.util.*;

public class Set3 {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("Raj");
		ts.add("Praveen");
		ts.add("Kumar");
	
		Iterator<String> it= ts.descendingIterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
		
		String search="Pravin";
		if(ts.contains(search))
		{
			System.out.println(search+" is present");
		}
		else
		{
			System.out.println(search+" is not present");
		}
	}

}
