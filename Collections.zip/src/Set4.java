import java.util.*;

public class Set4 {

	TreeSet<String> Country=new TreeSet<String>();
	TreeSet<String> saveCountryNames(String CountryName)
	{
		Country.add(CountryName);
		return Country;
	}
	String getCountry(String CountryName)
	{
		Iterator<String> it=Country.iterator();
		while(it.hasNext())
		{
			if(it.next().equals(CountryName))
			{
				return CountryName;
			}
		}
		return null;
	}
	public static void main(String[] args) {
		Set1 s=new Set1();
		System.out.println(s.saveCountryNames("India"));
		System.out.println(s.saveCountryNames("China"));
		System.out.println(s.getCountry("India"));
		System.out.println(s.getCountry("Japan"));
	}

}
