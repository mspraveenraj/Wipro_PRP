import java.util.*;

public class List3 {
	ArrayList<String> list=new ArrayList<String> ();
	void printAll()
	{
		Iterator<String> it=list.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	public static void main(String[] args) {
		List3 l=new List3();
		l.list.add("Raj");
		l.list.add("Praveen");
		l.list.add("Kumar");
		l.printAll();
	}

}
