import java.util.*;

public class Project1 implements Comparator<Project1>{

	String firstName;
	String lastName;
	String mobile;
	String email;
	String address;
	
	TreeSet<Project1> ts=new TreeSet<Project1>();
	
	Project1()
	{
		
	}
	
	Project1(String firstName, String lastName, String mobile, String email, String address)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.mobile=mobile;
		this.email=email;
		this.address=address;
	}
	
	//void addEmployee(Project1 e)
	//{/
	//	ts.add(e);
	//}
	
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		String firstName;
		String lastName;
		String mobile;
		String email;
		String address;
		
		System.out.println("Enter the Number of Employee : ");
		int n=in.nextInt();
		Project1 emp=new Project1();
		//Project1 emp1[]=new Project1[n];
		//Project1 em=new Employee1();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Employee "+i+1+" Details: ");
			System.out.println("Enter Firstname");
			firstName=in.next();
			System.out.println("Lastname");
			lastName=in.next();
			System.out.println("Enter the Mobile");
			mobile=in.next();
			System.out.println("Enter the Email");
			 email=in.next();
			System.out.println("Enter the Address");
			address=in.next();
			Project1 emp1=new Project1(firstName,lastName,mobile,email,address);
			emp.ts.add(emp1);
			
		}
		
		Iterator<Project1> it=emp.ts.iterator();
		while(it.hasNext())
		{
			Project1 st=(Project1)it.next();
			System.out.println(st.firstName+" "+st.lastName+" "+ st.mobile+" "+st.email+" "+st.address);
		}
		in.close();
	}

	/*public int compareTo(Object obj) {
		Project1 pro=(Project1)obj;
	
		if(pro.firstName.compareToIgnoreCase(firstName)==-1)
			return -1;
		else if(pro.firstName.compareToIgnoreCase(firstName)==1)
			return 1;
		return 0;
	}*/
	public String toString() {
		 return String.format("[Model:%s,Owner:%s,registeredCity:%s,ServiceDate:%s]", 
				 firstName,lastName,email,address.toString());
	 }

	@Override
	public int compare(Project1 firstName1, Project1 firstName2) {
		return firstName1.firstName.compareTo(firstName2.firstName);
	}

}
