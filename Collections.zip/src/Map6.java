import java.util.*;

public class Map6 {

		String CountryName;
		String capital;
			
		Hashtable<String, String> CountryMap=new Hashtable<String, String>();
		Set set=CountryMap.entrySet();
				
		Map6()
		{
			
		}
				
		Map6(String CountryName,String capital)
		{
			this.CountryName=CountryName;
			this.capital=capital;
		}
				
		Hashtable<String, String> saveCountryCapital(String CountryName, String capital)
		{
			CountryMap.put(CountryName,capital);
			return CountryMap;
		}
		
		String getCapital(String CountryName)
		{
			Enumeration it= CountryMap.keys();
			while(it.hasMoreElements())
			{
				String st=(String)it.nextElement();
				if(st.equals(CountryName))
				{
					return (String) CountryMap.get(st);
				}
			}
			return null;
		}
				
		String getCountry(String capitalName)
		{
			Iterator it=set.iterator();
			while(it.hasNext())
			{
				Map.Entry st=(Map.Entry)it.next();
				if(st.getValue().equals(capitalName))
				{
					return (String)st.getKey();
				}
			}
			return null;
		}
				
		Map interchange()
		{
			Hashtable M2=new Hashtable();
			Iterator it=set.iterator();
			while(it.hasNext())
			{
				Map.Entry st1=(Map.Entry)it.next();
				M2.put(st1.getValue(),st1.getKey());
			}
			return M2;
		}
				
		ArrayList arrayList()
		{
			ArrayList arr=new ArrayList();
			Iterator it=set.iterator();
			while(it.hasNext())
			{
				Map.Entry st2=(Map.Entry)it.next();
				arr.add(st2.getKey());
			}
			return arr;
		}
				
		public static void main(String[] args){
			Map6 mp=new Map6();
			
			System.out.println(mp.saveCountryCapital("India", "New Delhi"));
			System.out.println(mp.saveCountryCapital("India", "New Delhi"));
			System.out.println(mp.saveCountryCapital("China","Beijing"));
			System.out.println(mp.saveCountryCapital("Japan","Tokyo"));
			System.out.println(mp.getCapital("India"));
			System.out.println(mp.getCountry("Tokyo"));
			System.out.println(mp.interchange());
			System.out.println(mp.arrayList());
		}
	}
