import java.util.*;

public class Map2 {
	
	public static void main(String[] args) {
			
		Map<String, String> map=new HashMap<String,String>();
		
		map.put("12345","Raj");
		map.put("12346","Praveen");
		map.put("12347","Kumar");
		
		String searchKey="12346";
		String searchValue="Praveen";
		
		if(map.containsKey(searchKey))
			System.out.println("Key is Present");
		else
			System.out.println("Key is Not Present");
		if(map.containsValue(searchValue))
			System.out.println("Value is Present");
		else
			System.out.println("Value is Not Present");
		
		Set set=map.keySet();
		Iterator it=set.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
}
