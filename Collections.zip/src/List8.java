import java.util.*;

class Employee
{
	int id;
	String name;
	String address;
	
	Employee()
	{
		
	}
	
	Employee(int id,String name,String address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	
	public String toString()
	{
		return id+" "+name+" "+address;
	}
}
public class List8 {

	public static void main(String[] args) {
		Vector<Employee> emp=new Vector<Employee>();
		Employee emp1=new Employee(111,"Raj","Chennai");
		Employee emp2=new Employee(222,"Praveen","Kovai");
		Employee emp3=new Employee(333,"Kumar","Salem");
		emp.add(emp1);
		emp.add(emp2);
		emp.add(emp3);
		
		System.out.println("Iterator Iterations\n");
		Iterator it=emp.iterator();
		while(it.hasNext())
		{
			Employee st=(Employee)it.next();
			System.out.println(st.id+" "+st.name+" "+st.address);
		}
		
		System.out.println("\nEnum Iterations\n");
		Enumeration e=emp.elements();
		while(e.hasMoreElements())
		{
			System.out.println(e.nextElement().toString());
		}
	}

}
