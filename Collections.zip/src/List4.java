import java.util.*;

public class List4 {
	int a;
	float b;
	double c;
	 ArrayList<List4> list=new ArrayList<List4>();
	
	List4()
	{
		
	}
	
	List4(int a,float b,double c)
	{
		this.a=a;
		this.b=b;
		this.c=c;
	}
	
	public static void main(String[] args) {
		List4 l=new List4();
		l.list.add(new List4(1,2.0f,4.5));
		Iterator<List4> it=l.list.iterator();
		while(it.hasNext())
		{
			List4 lt=(List4)it.next();
			System.out.println( lt.a +" "+ lt.b + " "+ lt.c);
		}
	}

}
