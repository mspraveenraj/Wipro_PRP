package HandsOn;

import java.util.*;

public class FindStringCode {
		static int z=0;
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		String str=in.nextLine().toLowerCase();
		String a[]=str.split("\\s");
		
		int b[]=new int[a.length];
		FindStringCode fs=new FindStringCode();
		for(int i=0;i<a.length;i++)
		{
			b[i]=fs.findCode(a[i]);
			z=0;
		}
		
		for(int i=0;i<b.length;i++)
			System.out.print(b[i]);
		in.close();
	}
	
	 int findCode(String a)
	 {
		
		if(a.length()==0)
			return 0;
		else if(a.length()==1)
			return (int)(a.charAt(0)-'a')+1;
		else
			{
				z=Math.abs(a.charAt(0)-a.charAt(a.length()-1))+findCode(a.substring(1,a.length()-1));
			}
			return z;
	}

}
