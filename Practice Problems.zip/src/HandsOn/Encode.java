//2,5,1,7,9,3    3,-4,6,2,-6,3
package HandsOn;

import java.util.*;

public class Encode {

	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		int arr[]=new int[n];
		
		for(int i=0;i<n;i++)
		{
			arr[i]=in.nextInt();
		}
		
		for(int i=n-2;i>=0;i--)
		{
			arr[i]=arr[i]-arr[i+1];			//arr[i]=arr[i+1]-arr[i];	
		}
		
		int sum=0;
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
			sum+=arr[i];
		}
		
		System.out.println("First Index = "+arr[0]);
		System.out.println("Sum is = "+sum);
		in.close();
	}

}
