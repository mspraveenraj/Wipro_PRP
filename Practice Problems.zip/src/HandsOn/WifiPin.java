package HandsOn;

import java.util.*;
public class WifiPin {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		int roomNo;
		System.out.println("Enter Room Number");
		do{
			roomNo=in.nextInt();
		}while(!(roomNo>99 && roomNo<1000));
		
		System.out.println("Enter Last Name");
		String name=in.next();
		
		String pin="";
				
		// 1000 Position
		
		int sum=0;
		int n=roomNo;
		while(true)
		{
			sum=0;
			while(n>0)
			{
				int r=n%10;
				sum+=r;
				n/=10;
			}
			if(sum>9)
				n=sum;
			else
				break;
		}
		
		pin+=sum;
		
		//100 Position
		
		char arr[]={')','!','@','#','$','%','^','&','*','('};
		
		pin+=arr[roomNo%10];
		
		//10 Position
		
		pin+=name.charAt(name.length()-1);
		
		//0 Position
		
		int t=roomNo/10;
		pin+=t%10;
		
		System.out.println("Wi-Fi Pin is : "+pin);
		in.close();
	}

}
