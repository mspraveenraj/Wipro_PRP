package HandsOn;

public class ThreadDemo 
{

	public static void main(String[] args) throws InterruptedException 
	{
		Thread obj0=new Thread(new MyThread(),"Old Thread");
		Thread obj1=new Thread(new MyThread(),"New Thread");
		
		obj0.setPriority(Thread.MIN_PRIORITY);
		obj1.setPriority(Thread.MAX_PRIORITY);
		System.out.println(obj1);
		obj0.start();
		obj1.start();
		
		obj0.join();
		obj1.join();
	
		System.out.println("This is end of the main()");
	}

}

class MyThread implements Runnable
{

	@Override
	public void run() 
	{
			for(int i=1;i<=15;i++)
			{
				System.out.println(Thread.currentThread().getName() +" : " +i);
				try
				{
					Thread.sleep(500);
				}
				catch(InterruptedException e)
				{
				
				}
			}
	}
	
}
