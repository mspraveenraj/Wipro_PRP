package HandsOn;

import java.util.*;

public class num10_100_Pos {

	public static void main(String[] args) {
		
		Scanner in=new Scanner(System.in);
		int n=in.nextInt();
		
		int []a=new int[n];
		for(int i=0;i<4;i++)
		{
			a[i]=in.nextInt();
		}
		
		int sum=0;
		
		if(a[3]==0)
		{
			for(int i=0;i<3;i++)
			{
				int r=a[i]%10;
				sum+=r;
			}
		}
		else if(a[3]==1)
		{
			for(int i=0;i<3;i++)
			{
				int r=a[i]%100;
				sum+=r;
			}
		}
		//else if()

	}

}
