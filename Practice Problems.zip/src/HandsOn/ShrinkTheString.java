package HandsOn;

import java.util.*;

public class ShrinkTheString {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		
		String result="";
		
		int c=0;
		for(int i=0;i<str.length();i++)
		{
			c=0;
			char a=str.charAt(i); 
			result+=a;
			for(int j=0;j<str.length();j++)
			{
				if(a==str.charAt(j))
				{
					c++;
				}
			}
			if(c>2)
			{
				result+=c;
				str=str.replace(str.substring(i,i+1), "");
				i--;
			}
		}
		System.out.println(result);
		in.close();
	}
}