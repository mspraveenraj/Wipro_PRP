package HandsOn;

import java.util.*;

public class UserIdGeneration {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter First Name");
		String firstName=in.next();
		
		System.out.println("Enter Last Name");
		String lastName=in.next();
		
		System.out.println("Enter PIN");
		String pin=in.next();
		
		System.out.println("Enter N");
		int n=in.nextInt();
		
		String userId="";
		
		String longName="";
		String smallName="";
		
		if(firstName.length()>lastName.length())
		{
			longName+=firstName;
			smallName+=lastName;
		}
		else if(firstName.length()<lastName.length())
		{
			longName+=lastName;
			smallName+=firstName;
		}
		else if(firstName.length()==lastName.length())
		{
			if(firstName.compareTo(lastName)>=0)
			{
				longName+=firstName;
				smallName+=lastName;
			}
			else if(firstName.compareTo(lastName)<0)
			{
				longName+=lastName;
				smallName+=firstName;
			}
		}
		
		userId+=longName.charAt(0)+smallName+pin.charAt(n-1)+pin.charAt(pin.length()-n);
		
		String result="";
		for(int i=0;i<userId.length();i++)
		{
			if(Character.isUpperCase(userId.charAt(i)))
				result+=userId.substring(i,i+1).toLowerCase();
			else if(Character.isLowerCase(userId.charAt(i)))
				result+=userId.substring(i,i+1).toUpperCase();
			else
				result+=userId.charAt(i);
		}
		
		System.out.println(result);
		in.close();
	}
}
