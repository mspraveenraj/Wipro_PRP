//fi_er
//fever:filer:filter:fixer:fiber:fibre:tailor:offer

package HandsOn;

import java.util.Scanner;

public class MissingWord {

	public static void main(String[] args) {
		
		MissingWord ms=new MissingWord();
		Scanner in=new Scanner(System.in);
		String input1=in.next();
		String input2=in.next();
		
		String[] ch=input2.split(":");
		
		int index=0;
		
		for(int i=0;i<input1.length();i++)
		{
			if(input1.charAt(i)=='_')
			{
				index=i;
				input1=input1.replace("_","");
			}
		}
		
		int f=0;
		String str="";
		for(int i=0;i<ch.length;i++)
		{
			String x=ms.check(ch[i],index);
			if(x.equalsIgnoreCase(input1))
			{
				f++;
				str+=ch[i].toUpperCase()+":";
			}
		}		
			
		if(f==0)
			System.out.println("\"ERROR-009\"");		
		else
			System.out.println("\""+str.substring(0,str.length()-1)+"\"");
		in.close();
	}
	 
	String check(String str,int index)
	{
		StringBuffer sb=new StringBuffer(str);
		sb.delete(index,index+1);
	
		return sb.toString();
	}

}
