package HandsOn;

import java.util.*;

public class Encode_3_Strings {
	
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		String a=in.next();
		String b=in.next();
		String c=in.next();
		
		String sr[]=split1(a);
		String sr1[]=split1(b);
		String sr2[]=split1(c);
		
		System.out.println(sr[0]+" " +sr[1]+" "+sr[2]);
		System.out.println(sr1[0]+" " +sr1[1]+" "+sr1[2]);
		System.out.println(sr2[0]+" " +sr2[1]+" "+sr2[2]);
		
		String output1 = sr[0]+sr1[1]+sr2[2];
		String output2 = sr[1]+sr1[2]+sr2[0];
		String output3 = sr[2]+sr1[0]+sr2[1];
		System.out.println(output1+"\n"+output2+"\n"+output3);
		
		char str[]=output3.toCharArray();
		char str1[]=new char[str.length];
		
		for(int i=0;i<str.length;i++)
		{
			if(Character.isUpperCase(str[i]))
			{
				str1[i]=Character.toLowerCase(str[i]);
			}
			else if(Character.isLowerCase(str[i]))
			{
				str1[i]=Character.toUpperCase(str[i]);
			}
		}
		
		output3=String.valueOf(str1);
		System.out.println(output1+"\n"+output2+"\n"+output3);
		in.close();
	}
	
	static String[] split1(String s)
	{
		int l=s.length();
		String str[]=new String[3];
		
		if(l%3==0)
		{	int k=l/3;
				str[0]=s.substring(0,k);
				str[1]=s.substring(k,k+k);
				str[2]=s.substring(k+k);
		}
		
		else if(l%3==2)
		{
			int k=(l-2)/2;
			k+=1;
			str[0]=s.substring(0,k);
			str[1]=s.substring(k,k+1);
			str[2]=s.substring(k+1);
		}
		
		else if(l%3==1)
		{
			int k=(l-1)/2;
			str[0]=s.substring(0,k);
			str[1]=s.substring(k,k+2);
			str[2]=s.substring(k+2);
		}
		
		return str;
	}
}
