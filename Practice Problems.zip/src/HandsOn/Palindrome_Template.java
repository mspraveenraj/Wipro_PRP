package HandsOn;

import java.util.*;

public class Palindrome_Template {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		
		String str=in.next();
		str=str.toLowerCase();
		
		
		System.out.println(findLargePalindromeLength(str));
		in.close();
	}
	
	static int findLargePalindromeLength(String str)
	{

		String sub="";
		int len=str.length();
		int c=0;
		for(int i=len/2;i>=0;i--)
		{
				if(str.endsWith(str.substring(0,i)))
				{
					sub+=str.substring(0,i);
					break;
				}
				c++;
		}
		
		if(c==len/2)
			return -1;
		
		String cut=str.substring(sub.length(),str.length()-sub.length());
		//System.out.println(cut);
		
		int real=2*sub.length();
	
			if(cut.length()>0)
				real+=1;
			
		//System.out.println(sub);
		//System.out.println(real);
		return real;
	}

}
