package HandsOn;

import java.util.*;
public class Stable {

	public static void main(String[] args) {
		Stable s=new Stable();
		Scanner in=new Scanner(System.in);
		int a[]=new int[5];
		int b[]=new int[5];
		
		for(int i=0;i<5;i++)
		{
			a[i]=in.nextInt();
		}
		
		
		for(int i=0;i<5;i++)
		{
			b[i]=s.stable(a[i]);
			System.out.println(b[i]);
		}
		
		int max=0;
		int min=99999999;
		for(int i=0;i<5;i++)
		{
			if(b[i]==1)
			{
				if(max<a[i])
					max=a[i];
			}
	
			if(b[i]==0)
			{
				if(min>a[i])
					min=a[i];
			}
		}
		
		System.out.println("Password = "+(max-min));
		in.close();
	}
	
	int stable(int n)
	{
		String str=String.valueOf(n);
		
		int c=0;
		
		for(int i=0;i<str.length();i++)
		{
			for(int j=0;j<str.length();j++)
			{
				if(str.charAt(i)==str.charAt(j))
				{
					c++;
				}
			}
		}
		System.out.println(c);
		if(c==str.length() || c/2==str.length())
			return 1;
		return 0;
	}

}
