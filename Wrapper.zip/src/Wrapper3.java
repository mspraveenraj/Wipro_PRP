import java.util.*;

public class Wrapper3 {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the Number (1-255) :");
		Integer num=in.nextInt();
		if(num>0&&num<256)
		{
			String n=Integer.toBinaryString(num);
			n=String.format("%8s", n);
			n=n.replace(" ","0");
			System.out.println(n);
		}
		else
			System.out.println("Invalid Entered Number");
		in.close();
	}

}
