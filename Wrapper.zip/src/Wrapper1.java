
public class Wrapper1 {

	public static void main(String[] args) {
		System.out.println("      Byte range : \nmin = " + Byte.MIN_VALUE);
	    System.out.println("max = " + Byte.MAX_VALUE);
	    System.out.println("      Short range :\nmin = " + Short.MIN_VALUE);
	    System.out.println("max = " + Short.MAX_VALUE);
	    System.out.println("      Integer range :\nmin = " + Integer.MIN_VALUE);
	    System.out.println("max = " + Integer.MAX_VALUE);
	    System.out.println("      Long range :\nmin = " + Long.MIN_VALUE);
	    System.out.println("max = " + Long.MAX_VALUE);
	    System.out.println("      Float range :\nmin = " + Float.MIN_VALUE);
	    System.out.println("max = " + Float.MAX_VALUE);
	    System.out.println("      Double range :\nmin = " + Double.MIN_VALUE);
	    System.out.println("max = " + Double.MAX_VALUE);

	}

}
