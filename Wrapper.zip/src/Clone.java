class Employee implements Cloneable
{
	int empId;
	String name;
	Employee test()
	{
		try
		{
			return (Employee) super.clone();
		}
		catch(CloneNotSupportedException e)
		{
			System.out.println("Cloning Not Allowed");
			return this;
		}
	}
}
public class Clone {

	public static void main(String[] args) {
		Employee e1=new Employee();
		Employee e2=new Employee();
		e1.empId=1234;
		e1.name="Raj";
		e2=e1.test();
		System.out.println("\t\tBefore Cloning\nEmployee 1 :\nEmp Id : "+e1.empId);
		System.out.println("Emp Name : "+e1.name);
		e1.empId=4567;
		e2.name="Praveen";
		System.out.println("\n\t\tAfter Cloning\nEmployee 1 :\nEmp Id : "+e1.empId);
		System.out.println("Emp Name : "+e1.name);
		System.out.println("\nEmployee 2 :\nEmp Id : "+e2.empId);
		System.out.println("Emp Name : "+e2.name);
	}
}