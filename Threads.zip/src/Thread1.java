
public class Thread1 implements Runnable {

	public void run()
	{
		System.out.println(Thread.currentThread().getName()+" ruuning...");
	}
	public static void main(String[] args) {
		Thread1 t=new Thread1();
		Thread t1=new Thread(t,"Scobby");
		Thread t2=new Thread(t,"Shaggy");
		t1.start();
		t2.start();
	}

}
