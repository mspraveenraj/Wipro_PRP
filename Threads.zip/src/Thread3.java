
class SalesPersons implements Runnable
{
	Thread t;
	
	SalesPersons()
	{
		t=new Thread(this);
		t.start();
	}
	
	public void run()
	{
		System.out.println("P1 P2 P3 P4 P5");
	}

	@SuppressWarnings("deprecation")
	public void suspend() {
		t.suspend();
	}

	@SuppressWarnings("deprecation")
	public void resume() {
		t.resume();
	}
}
	
class Days implements Runnable
{
	Thread t;
	SalesPersons s;
	String []days={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saurday"};
	Days()
	{
		
		s=new SalesPersons();
		
		t=new Thread(this);
		t.start();
		//System.out.println("hai");
	}
	
	public void run()
	{//System.out.println("hi");
		
		for(int i=0;i<31;i++)
		{
			int l=i%7;
			System.out.println(l);
			
			if(days[l].equals("Sunday"))
			{
				s.suspend();
				System.out.println("Suspended");
			}
			else if(days[l].equals("Wednesday"))
			{
				s.resume();
				System.out.println("Resumed");
			}
		}
		
		//System.out.println(Thread.currentThread().getName()+ " is Selling...");
	}
}
public class Thread3 extends SalesPersons {

	public static void main(String[] args) {
		new Days();
	}

}
