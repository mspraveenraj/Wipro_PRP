/*Create two threads, one thread to display all even numbers between 1 & 20, another to display odd numbers between 1 & 20.
Note: Display all even numbers followed by odd numbers
Hint: use join*/

class Even implements Runnable
{
	public void run()
	{
		for(int i=1;i<=20;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}
}

class Odd implements Runnable
{
	public void run()
	{
		for(int i=1;i<=20;i++)
		{
			if(i%2==1)
			{
				System.out.println(i);
			}
		}
	}
}

public class Thread5 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread t1=new Thread(new Even(),"Even Thread");
		Thread t2=new Thread(new Odd(),"Odd Thread");
		
		t1.start();
		t1.join();
		t2.start();

	}

}
