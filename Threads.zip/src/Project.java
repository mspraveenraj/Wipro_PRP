class Hare implements Runnable
{
	
	@SuppressWarnings("deprecation")
	public void run()
	{
		for(int i=0;i<100;i++)
		{
			System.out.println(Thread.currentThread().getName()+" is running "+i+ " meters");
			
			if(Thread.currentThread().getName().equals("Hare") && i==99)
			{
				Project.tortoise.stop();
				System.out.println("\nHare is Finished...");
			}
			
			else if(Thread.currentThread().getName().equals("Tortoise") && i==99)
			{
				Project.hare.stop();
				System.out.println("\nTortoise is Finished...");
			}
			
			if(Thread.currentThread().getName().equals("Hare") && i==59)
			{
				try
				{
					System.out.println("Hare Sleeps");
					Thread.sleep(1000);
				}
				
				catch(InterruptedException e)
				{
					System.out.println("Thread exception Occured !!!");
				}
				
			}
			
		}
		
	}
	
}

public class Project 
{
	static Thread hare=new Thread(new Hare(),"Hare");
	static Thread tortoise=new Thread(new Hare(),"Tortoise");
	
	public static void main(String[] args) 
	{
		hare.setPriority(Thread.MAX_PRIORITY);
		tortoise.setPriority(Thread.MIN_PRIORITY);
		hare.start();
		tortoise.start();
	}
}
