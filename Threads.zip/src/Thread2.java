import java.util.Random;

public class Thread2 implements Runnable{

	public void run()
	{
		System.out.println(Thread.currentThread().getName()+ " is Running...");
	}
	public static void main(String[] args) {
		Thread2 t=new Thread2();
		String colours[]={"white","blue","black","green","red","yellow"};
		Random r=new Random();
		for(int i=0;;i++)
		{
			int l=Math.abs(r.nextInt()%6);
			System.out.println(l);
			if(colours[l].equals("red"))
				break;
			
			Thread t1=new Thread(t,colours[l]);
			t1.start();
		}

	}

}
