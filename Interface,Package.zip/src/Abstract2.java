import java.util.Random;

abstract class Compartment
{
	abstract void notice();
}

class FirstClass extends Compartment
{
	void notice()
	{
		System.out.println("First Class");
	}
}
class Ladies extends Compartment
{
	void notice()
	{
		System.out.println("Ladies");
	}
}

class General extends Compartment
{
	void notice()
	{
		System.out.println("General");
	}
}

class Luggage extends Compartment
{
	void notice()
	{
		System.out.println("Luggage");
	}
}

public class Abstract2
{

	public static void main(String[] args)
	{
		Compartment com[]=new Compartment[10];
		Random r=new Random();
		for(int i=0;i<10;i++)
		{
		int n=r.nextInt(4);
		if(n==0)
		{
			com[i]=new FirstClass();
			com[i].notice();
		}
		if(n==1)
		{
			com[i]=new Ladies();
			com[i].notice();
		}
		
	  if(n==2)
		{
			com[i]=new General();
			com[i].notice();
		}
		if(n==3)
		{
			com[i]=new Luggage();
			com[i].notice();
		}
		}

  }
}
