package com.automobile.TwoWheeler;

import com.automobile.Vehicle;

class Honda extends Vehicle
{
	
	public String getModelName()
	{
		return "R15";
	}
	public String getRegistrationNumber()
	{
		return "TN 25 A 1231";
	}
	public String getOwnerName()
	{
		return "Praveen";
	}
	public int getSpeed()
	{
		return 230;	
	}
	public void cdplayer()
	{
		System.out.println("CD Player is Playing Now");
	}
}