package com.automobile.TwoWheeler;
import com.automobile.Vehicle;
class Hero extends Vehicle 
{
	public String getModelName()
	{
		return "RX100";
	}
	public String getRegistrationNumber()
	{
		return "TN 77 D 1234";
	}
	public String getOwnerName()
	{
		return "Raj";
	}
	public int getSpeed()
	{
		return 124;
	}
	
	public void radio()
	{
		System.out.println("Radio is ON");
	}
}

