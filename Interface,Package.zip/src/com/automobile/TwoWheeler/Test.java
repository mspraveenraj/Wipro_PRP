package com.automobile.TwoWheeler;

import com.automobile.FourWheeler.*;

public class Test {

	public static void main(String[] args) {
		
		System.out.println("\t\tTwo Wheeler");
		Hero he=new Hero();
		System.out.println("       Hero Class\nModel Name : "+he.getModelName());
		System.out.println("Registration Number : "+he.getRegistrationNumber());
		System.out.println("Owner Name : "+he.getOwnerName());
		System.out.println("Speed : "+he.getSpeed());
		he.radio();
		
		Honda ho=new Honda();
		System.out.println("       Honda Class\nModel Name : "+ho.getModelName());
		System.out.println("Registration Number : "+ho.getRegistrationNumber());
		System.out.println("Owner Name : "+ho.getOwnerName());
		System.out.println("Speed : "+ho.getSpeed());
		ho.cdplayer();
		
		System.out.println("\t\tFour Wheeler");
		Logan lo=new Logan();
		System.out.println("       Logan Class\nModel Name : "+lo.getModelName());
		System.out.println("Registration Number : "+lo.getRegistrationNumber());
		System.out.println("Owner Name : "+lo.getOwnerName());
		System.out.println("Speed : "+lo.getSpeed());
		System.out.println("GPS is activated at Position : "+lo.gps());
		
		Ford fo=new Ford();
		System.out.println("       Ford Class\nModel Name : "+fo.getModelName());
		System.out.println("Registration Number : "+fo.getRegistrationNumber());
		System.out.println("Owner Name : "+fo.getOwnerName());
		System.out.println("Speed : "+fo.getSpeed());
		System.out.println("Temperature is : "+fo.tempControl());
	}

}
