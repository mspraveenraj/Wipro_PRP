package com.automobile.FourWheeler;

import com.automobile.Vehicle;
public class Logan extends Vehicle
{	
	public String getModelName()
	{
		return "SD123";
	}
	public String getRegistrationNumber()
	{
		return "TN 25 A 2222";
	}
	public String getOwnerName()
	{
		return "Praveen";
	}
	public int getSpeed()
	{
		return 230;	
	}

	public int gps() 
	{
		return 123;
	}
}
