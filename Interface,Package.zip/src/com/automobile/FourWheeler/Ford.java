package com.automobile.FourWheeler;

import com.automobile.Vehicle;

public class Ford extends Vehicle {
	
	public String getModelName()
	{
		return "SX140";
	}
	public String getRegistrationNumber()
	{
		return "TN 25 A 1111";
	}
	public String getOwnerName()
	{
		return "Praveen";
	}
	public int getSpeed()
	{
		return 230;	
	}

	public int tempControl() 
	{
		return 45;
	}
}
