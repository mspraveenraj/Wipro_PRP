package com.wipro.automobile.ship;

class Compartment
{
	double height=10.0;
	double weight=20.0;
	double width=30.0;
	
}
public class Package2 {

	public static void main(String[] args) {
		Compartment c=new Compartment();
		System.out.println(c.height);
		System.out.println(c.weight);
		System.out.println(c.width);
	}

}
