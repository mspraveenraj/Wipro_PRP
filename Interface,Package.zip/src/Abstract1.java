abstract class GeneralBank
{
	abstract double getSavingInterestRate();
	abstract double getFixedInterestRate();
}

class ICICIBank extends GeneralBank
{
	double getSavingInterestRate()
	{
		return 4.0/100;
		
	}
	double getFixedInterestRate()
	{
		return 8.5/100;
	}
}

class KotMBank extends GeneralBank
{
	double getSavingInterestRate()
	{
		return  6.0/100; 

	}
	double getFixedInterestRate()
	{
		return 9.0/100;
	}
}
public class Abstract1 {

	public static void main(String[] args) {
         ICICIBank ic=new ICICIBank();
         System.out.println("     ICICIBank\n"+"Saving Interest : "+ic.getSavingInterestRate()+"\nFixed Interest : "+ic.getFixedInterestRate());
         KotMBank ik=new KotMBank();
         System.out.println("     KotMBank\n"+"Saving Interest : "+ik.getSavingInterestRate()+"\nFixed Interest : "+ik.getFixedInterestRate());
         GeneralBank gbk=new KotMBank();
         System.out.println("     KotMBank\n"+"Saving Interest : "+gbk.getSavingInterestRate()+"\nFixed Interest : "+gbk.getFixedInterestRate());
         GeneralBank gbi=new ICICIBank();    
         System.out.println("     ICICIBank\n"+"Saving Interest : "+gbi.getSavingInterestRate()+"\nFixed Interest : "+gbi.getFixedInterestRate());
   }

}
