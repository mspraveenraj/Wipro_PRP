import java.util.Scanner;

abstract class Instrument
{
	abstract void play();
}

class Piano extends Instrument
{
	void play()
	{
		System.out.println("Piano is playing  tan tan tan tan ");
	}
}

class Flute extends Instrument
{
	void play()
	{
		System.out.println("Flute is playing  toot toot toot toot");
	}
}

class Guitar extends Instrument
{
	void play()
	{
		System.out.println("Guitar is playing  tin  tin  tin ");
	}
}

public class Abstract3 {

	public static void main(String[] args) {
		String instrument[]=new String[10];
		Scanner in=new Scanner(System.in);
		Instrument ins;
		System.out.println("Enter 10 Instruments (Piano/Flute/Guitar)");
		for(int i=0;i<10;i++)
		{
			instrument[i]=in.next();
		}
		for(int i=0;i<10;i++)
		{
			if(instrument[i].equals("Piano"))
			{
				ins=new Piano();
			}
			else if(instrument[i].equals("Flute"))
			{
				ins=new Flute();
			}
			else
			{
				ins=new Guitar();
			}
			if(ins instanceof Piano)
			{
				ins.play();
			}
			else if(ins instanceof Flute)
			{
				ins.play();
			}
			else if(ins instanceof Guitar)
			{
				ins.play();
			}
				
		}
		in.close();
	}
}
